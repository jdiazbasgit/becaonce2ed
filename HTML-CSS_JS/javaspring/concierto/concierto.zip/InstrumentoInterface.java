


public interface InstrumentoInterface {

	
	public  String sonar();
}