


public class Solista extends Musico {

	
	public void tocar(){
		System.out.println(getInstrumento().sonar());
	}
}