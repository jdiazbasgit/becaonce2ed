

/**
 * @author fjdia
 * @version 1.0
 * @created 22-dic.-2022 9:40:40
 */
public class HombreOrquesta extends Musico {

	public HombreOrquesta(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}
	public void tocar(){

	}
}//end HombreOrquesta