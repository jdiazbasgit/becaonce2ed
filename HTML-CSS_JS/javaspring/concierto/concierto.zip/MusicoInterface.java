


public interface MusicoInterface {

	public  void tocar();
}